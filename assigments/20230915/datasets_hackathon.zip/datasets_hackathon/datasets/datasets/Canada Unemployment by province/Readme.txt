-------------------------- About the data --------------------------
This data covers the unemployment rate for different Canadian provinces and cover the years 1976-"present" (present being whenever the last of the data was collected)

-------------------------- Features --------------------------

REF_DATE:The reference period (by year, month)

GEO: The geographic area

Sex: The sex being investigated

Age group: The age group of the economic measure

Employment: Number of persons who, during the reference week, worked for pay or profit, or performed unpaid family work or had a job but were not at work due to own illness or disability, personal or family responsibilities, labour dispute, vacation, or other reason.

Full-time employment: Full-time employment consists of persons who usually work 30 hours or more per week at their main or only job.

Labour force: Number of civilian, non-institutionalized persons 15 years of age and over who, during the reference week, were employed or unemployed.

Part-time employment: Part-time employment consists of persons who usually work less than 30 hours per week at their main or only job.

Part-time employment consists of persons who usually work less than 30 hours per week at their main or only job.

Population: Number of persons of working age, 15 years and over.

Unemployment: Number of persons who, during the reference week, were without work, had looked for work in the past four weeks, and were available for work. Those persons on layoff or who had a new job to start in four weeks or less are considered unemployed.

Employment rate: The employment rate is the number of persons employed expressed as a percentage of the population 15 years of age and over.

Participation rate: The participation rate is the number of labour force participants expressed as a percentage of the population 15 years of age and over.

Unemployment rate: The unemployment rate is the number of unemployed persons expressed as a percentage of the labour force.